class ImageAssetsConst {

  static const String plotRolLogo = 'assets/images/native_splash.png';
}